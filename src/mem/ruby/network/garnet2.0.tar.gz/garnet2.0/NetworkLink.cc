/*
 * Copyright (c) 2008 Princeton University
 * Copyright (c) 2016 Georgia Institute of Technology
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met: redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer;
 * redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution;
 * neither the name of the copyright holders nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Authors: Niket Agarwal
 *          Tushar Krishna
 */


#include "mem/ruby/network/garnet2.0/NetworkLink.hh"

#include "mem/ruby/network/garnet2.0/CreditLink.hh"

#include "mem/ruby/scratchpad/MemMessage.hh"
#include "mem/ruby/network/garnet2.0/NetworkInterface.hh"
#include "debug/Mesh.hh"
#include "debug/RubyNetwork.hh"

NetworkLink::NetworkLink(const Params *p)
    : ClockedObject(p), Consumer(this), m_id(p->link_id),
      m_type(NUM_LINK_TYPES_),
      m_latency(p->link_latency),
    //   m_latency(0),
      linkBuffer(new flitBuffer()), link_consumer(nullptr),
      link_srcQueue(nullptr), m_link_utilized(0),
      m_vc_load(p->vcs_per_vnet * p->virt_nets)
{
}

NetworkLink::~NetworkLink()
{
    delete linkBuffer;
}

void
NetworkLink::setLinkConsumer(Consumer *consumer)
{
    link_consumer = consumer;
}

void
NetworkLink::setSourceQueue(flitBuffer *srcQueue)
{
    link_srcQueue = srcQueue;
}

void
NetworkLink::wakeup()
{
    if (link_srcQueue->isReady(curCycle())) {
    // if (link_srcQueue->isReady(curTick())) {
        flit *t_flit = link_srcQueue->getTopFlit();

        // auto mem_msg = std::dynamic_pointer_cast<MemMessage>(t_flit->get_msg_ptr());
        // if (mem_msg != nullptr && mem_msg->getPacket()->getAddr() >= 0x20000000) 
        //   DPRINTF(Mesh, "NetworkLink %d delay %d push %#x\n", m_id, m_latency, mem_msg->getPacket()->getAddr());


        DPRINTF(RubyNetwork, "NetworkLink %d wakeup flit ptr %p rem flits %d\n", m_id, t_flit, link_srcQueue->getSize());

        // t_flit->set_time(curCycle() + m_latency);
        linkBuffer->insert(t_flit);
        // link_consumer->scheduleEventAbsolute(clockEdge(m_latency));
        // if (mem_msg != nullptr && mem_msg->getPacket()->getAddr() >= 0x20000000) {
        //     link_consumer->scheduleEventAbsolute(clockEdge(Cycles(0)) + 1);
        //     t_flit->set_time(curTick() + (Tick)1);
        // }
        // else
        //     link_consumer->scheduleEventAbsolute(clockEdge(m_latency));

        // if this is going to a network interface don't allow on odd cycle
        Tick schedTime;
        if (dynamic_cast<NetworkInterface*>(link_consumer)) {
            schedTime = clockEdge(m_latency);
        }
        else {
            schedTime = curTick() + 1;
        }

        link_consumer->scheduleEventAbsolute(schedTime);
        t_flit->set_time(schedTime);
        m_link_utilized++;
        m_vc_load[t_flit->get_vc()]++;

    }
}

void
NetworkLink::resetStats()
{
    for (int i = 0; i < m_vc_load.size(); i++) {
        m_vc_load[i] = 0;
    }

    m_link_utilized = 0;
}

NetworkLink *
NetworkLinkParams::create()
{
    return new NetworkLink(this);
}

CreditLink *
CreditLinkParams::create()
{
    return new CreditLink(this);
}

uint32_t
NetworkLink::functionalWrite(Packet *pkt)
{
    return linkBuffer->functionalWrite(pkt);
}

bool
NetworkLink::functionalRead(Packet *pkt)
{
    return linkBuffer->functionalRead(pkt);
}
